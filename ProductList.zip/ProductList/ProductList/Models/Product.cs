﻿using System.ComponentModel.DataAnnotations;

namespace ProductList.Models
{
    public class Product
    {
        [Key]
        public int Pno { get; set; }
        public string Pname { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public string Quantity { get; set; }
    }
}


